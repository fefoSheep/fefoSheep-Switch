#include <string.h>
#include <iostream>

#include <switch.h>
using namespace std;
int main(int argc, char* argv[])
{


    

    while(appletMainLoop())
    {
    consoleInit(NULL);
        //Scan all the inputs. This should be done once for each frame
        hidScanInput();

        //hidKeysDown returns information about which buttons have been just pressed (and they weren't in the previous frame)
        u32 kDown = hidKeysDown(CONTROLLER_P1_AUTO);



    int A = 0;

    cout << "YAFSM sWoTCH Wartortle eedishun\n";
    cout << "version 0.6.0\n";
    for(A = 0; A < 60000; A = A+5){
    if (kDown & KEY_A) break;
    if (A == 1800)
{ 
                    cout << "if it dont work then go for a\n";
                    cout << "henati break and try again lator\n";
                    cout << "if u too scared for pokegomz pres +\n";
}
    if (A == 3600) cout << "DOWNLAOD FLIES OF POKEGOMZ!!\n";
    if (A == 5400) cout << "DOWNOLA COMPETE!!\n";
    if (A == 7200)
{
                   cout << "bribing gam freck to\n";
                   cout << "#brinbaknashunaldechs\n";
}
    if (A == 9600) cout << "DOANLOAD AND INSTAL FRII LGPE NSP\n";
    if (A == 10200)
{
                    cout << "now downloa and isntal xy\n";
                    cout << "oras sm usum port for swithc\n";
}
    if (A == 10800)
{
                    cout << "doanola and instal dpp hgss\n";
                    cout << "bw b2w2 port for swotch\n";
}
    if (A == 11400) cout << "doanlaod and isntall rse frlg port for swith\n";
    if (A == 13200) cout << "doanloa and instal gsc rby port for swoth\n";
    if (A == 15000) cout << "jus mak sur u don kil ur pokegomz or u bric!!\n";
    if (A == 16800) cout << "runing clongo exploit..\n";
    if (A == 18600) cout << "dongrodi to 1.0.0\n";
    if (A == 20400) cout << "pathcing flies of pokegomz..\n";
    if (A == 22200) cout << "sicc now generat new systume imag..\n";
    if (A == 23400) cout << "systume imag genrat nowa flash ontoo emptii brian\n";
    if (A == 25200) cout << "doo sam ting with recuvurii and fei partishuns\n";
    if (A == 26100) cout << "nowe update from dum atmosfer to raynx\n";
    if (A == 27000) cout << "now u hav raynx becaus atmosfer succ 4-bite bik\n";
    if (A == 27900) cout << "donola 2TB reshiram\n";
    if (A == 28800) cout << "flash by-os form u..\n";
    if (A == 29700) cout << "arguin in #meta abot rul 11..\n";
    if (A == 30600) cout << "OH NO HECK U GOT FRIKKEN BAN BY MASUDA!!\n";
    if (A == 31500) cout << "runin sube too mellzbaxfrend (ur such a hackers)\n";
    if (A == 32400) cout << "u got aron ban my dud!!\n";
    if (A == 33300) cout << "cunvirtin flies of pokegomz\n";
    if (A == 34200) cout << "now imparti flies of pokegomz..\n";
    if (A == 35100) cout << "gib u pokegomz in rel lif..\n";
    if (A == 36000) cout << "Nowe u hav a rel liv Wartortle!!!!!\n";
        consoleUpdate(NULL);
    }
        if (kDown & KEY_PLUS) break; // break in order to return to hbmenu
}
    consoleExit(NULL);
    gfxExit();
    return 0;
}

